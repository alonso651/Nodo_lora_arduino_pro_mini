# I no longer use this repository. 
### I'll leave it up in case some old projects rely on it, but I have for quite a while strived to contribute all new symbols, footprints and 3D models to the upstream kicad repositories, and I encourange people to do the same. Check out the [KiCAD Library Convention](http://kicad-pcb.org/libraries/klc/) documentation if you're interested/

# kicad-libraries
A collection of all the parts and footprints that I use in KiCAD

Noteable mentions for google:

* Kailh PCB sockets, dimensions gotten from: https://github.com/skullydazed/clueboard_eagle
